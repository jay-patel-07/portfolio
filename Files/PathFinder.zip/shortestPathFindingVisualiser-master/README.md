# shortestPathFindingVisualiser
This project is an application of unweighted Dijkstra. It visualizes the shorest path between the start and end points having walls in the between. 
This GUI was made by using Java Swing. (06/2020 - 06/2020)

Now, in the GUI, click once to get the starting point on one of the cells. 
If you click twice on any cell, then that cell will be converted to a wall; however, click thrice to make it a finish point.
That's is, now after all, just press the "GO" button and you will get the shortest path between starting and finish point.
