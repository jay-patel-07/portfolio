# prOmega
It was a group project and it is a website of Society name Avadh Lake City, Surat. It is made using HTML, CSS, JavaScript, PHP and Xampp for DataBase.
